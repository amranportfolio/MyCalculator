package com.example

import com.example.domain.AngleMode
import com.example.domain.CalcErrorType
import com.example.domain.CalculatorEngine
import com.example.domain.EvalResult
import com.example.domain.UnitCategory
import com.example.domain.UnitConverter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorEngineTest {

    @Test
    fun `exact decimal addition avoids floating point drift`() {
        val result = CalculatorEngine.evaluate("0.1+0.2")
        assertTrue(result is EvalResult.Success)
        assertEquals("0.3", (result as EvalResult.Success).formatted)
    }

    @Test
    fun `operator precedence and implicit multiplication work accurately`() {
        val result = CalculatorEngine.evaluate("2+3×4(1+1)")
        assertTrue(result is EvalResult.Success)
        assertEquals("26", (result as EvalResult.Success).formatted)
    }

    @Test
    fun `trigonometric snapping in DEG and RAD modes`() {
        val sin30 = CalculatorEngine.evaluate("sin(30)", AngleMode.DEG) as EvalResult.Success
        assertEquals("0.5", sin30.formatted)

        val cos90 = CalculatorEngine.evaluate("cos(90)", AngleMode.DEG) as EvalResult.Success
        assertEquals("0", cos90.formatted)

        val tan90 = CalculatorEngine.evaluate("tan(90)", AngleMode.DEG)
        assertEquals(EvalResult.Error(CalcErrorType.DOMAIN), tan90)

        val cosPi = CalculatorEngine.evaluate("cos(π)", AngleMode.RAD) as EvalResult.Success
        assertEquals("-1", cosPi.formatted)
    }

    @Test
    fun `percentage factorial and powers evaluate accurately`() {
        val pct = CalculatorEngine.evaluate("200×15%") as EvalResult.Success
        assertEquals("30", pct.formatted)

        val fact = CalculatorEngine.evaluate("5!") as EvalResult.Success
        assertEquals("120", fact.formatted)

        val pow = CalculatorEngine.evaluate("2^10") as EvalResult.Success
        assertEquals("1,024", pow.formatted)
    }

    @Test
    fun `division by zero and negative sqrt return proper errors`() {
        assertEquals(
            EvalResult.Error(CalcErrorType.DIVIDE_BY_ZERO),
            CalculatorEngine.evaluate("42÷0")
        )
        assertEquals(
            EvalResult.Error(CalcErrorType.DOMAIN),
            CalculatorEngine.evaluate("√(−9)")
        )
    }

    @Test
    fun `unit converter converts temperature and length accurately`() {
        val tempUnits = UnitConverter.unitsByCategory[UnitCategory.TEMPERATURE]!!
        val c = tempUnits.first { it.id == "c" }
        val f = tempUnits.first { it.id == "f" }
        assertEquals(212.0, UnitConverter.convert(100.0, UnitCategory.TEMPERATURE, c, f), 1e-6)

        val lengthUnits = UnitConverter.unitsByCategory[UnitCategory.LENGTH]!!
        val km = lengthUnits.first { it.id == "km" }
        val m = lengthUnits.first { it.id == "m" }
        assertEquals(1500.0, UnitConverter.convert(1.5, UnitCategory.LENGTH, km, m), 1e-6)
    }
}
