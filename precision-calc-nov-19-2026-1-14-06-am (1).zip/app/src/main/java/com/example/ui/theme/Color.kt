package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Precision Instrument Palette — Coral Ember Accent & Matte Graphite / Alabaster Surfaces
val CoralEmber = Color(0xFFFF6B2C)
val CoralEmberDeep = Color(0xFFE55317)
val CoralEmberSoft = Color(0xFFFF8F5E)

// Dark (Obsidian & Graphite)
val ObsidianBackground = Color(0xFF0D0F13)
val ObsidianDeck = Color(0xFF141820)
val GraphiteKeycap = Color(0xFF1D222C)
val GraphiteKeycapElevated = Color(0xFF262D3B)
val ObsidianOperatorBg = Color(0xFF2F211B)
val ObsidianClearBg = Color(0xFF381E24)
val ObsidianClearText = Color(0xFFFF7D8A)
val ObsidianTextPrimary = Color(0xFFF3F6FA)
val ObsidianTextSecondary = Color(0xFF94A0B4)
val ObsidianOutline = Color(0xFF2C3442)
val ObsidianSciBg = Color(0xFF18202B)
val ObsidianSciText = Color(0xFF7CB7FF)

// Light (Alabaster & Warm Steel)
val AlabasterBackground = Color(0xFFF1F3F7)
val AlabasterDeck = Color(0xFFFFFFFF)
val AlabasterKeycap = Color(0xFFFFFFFF)
val AlabasterKeycapElevated = Color(0xFFE5E9F0)
val AlabasterOperatorBg = Color(0xFFFCE9E1)
val AlabasterClearBg = Color(0xFFFBE4E7)
val AlabasterClearText = Color(0xFFC62839)
val AlabasterTextPrimary = Color(0xFF131720)
val AlabasterTextSecondary = Color(0xFF5D6778)
val AlabasterOutline = Color(0xFFD9DFE8)
val AlabasterSciBg = Color(0xFFE6ECF5)
val AlabasterSciText = Color(0xFF1A5FB4)
