package com.example.ui.converter

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.MeasureUnit
import com.example.domain.UnitCategory
import com.example.domain.UnitConverter
import com.example.ui.CalculatorUiState
import com.example.ui.components.KeyRole
import com.example.ui.components.TactileKey
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCalculatorPalette

@Composable
fun UnitConverterScreen(
    state: CalculatorUiState,
    isWideLayout: Boolean,
    onSelectCategory: (UnitCategory) -> Unit,
    onSelectFromUnit: (MeasureUnit) -> Unit,
    onSelectToUnit: (MeasureUnit) -> Unit,
    onSwapUnits: () -> Unit,
    onDigit: (String) -> Unit,
    onDecimal: () -> Unit,
    onToggleSign: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val units = UnitConverter.unitsByCategory[state.converterCategory].orEmpty()

    if (isWideLayout) {
        Row(
            modifier = modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CategoryChipRow(
                    selected = state.converterCategory,
                    onSelect = onSelectCategory
                )
                ConverterCardsPair(
                    input = state.converterInput,
                    output = state.converterOutput,
                    fromUnit = state.converterFromUnit,
                    toUnit = state.converterToUnit,
                    units = units,
                    onSelectFromUnit = onSelectFromUnit,
                    onSelectToUnit = onSelectToUnit,
                    onSwapUnits = onSwapUnits
                )
                ConverterKeypad(
                    hapticsEnabled = state.hapticsEnabled,
                    onDigit = onDigit,
                    onDecimal = onDecimal,
                    onToggleSign = onToggleSign,
                    onBackspace = onBackspace,
                    onClear = onClear,
                    onSwapUnits = onSwapUnits,
                    modifier = Modifier.weight(1f)
                )
            }

            ConverterReferencePane(
                state = state,
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
            )
        }
    } else {
        Column(
            modifier = modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CategoryChipRow(
                selected = state.converterCategory,
                onSelect = onSelectCategory
            )
            ConverterCardsPair(
                input = state.converterInput,
                output = state.converterOutput,
                fromUnit = state.converterFromUnit,
                toUnit = state.converterToUnit,
                units = units,
                onSelectFromUnit = onSelectFromUnit,
                onSelectToUnit = onSelectToUnit,
                onSwapUnits = onSwapUnits
            )
            ConverterKeypad(
                hapticsEnabled = state.hapticsEnabled,
                onDigit = onDigit,
                onDecimal = onDecimal,
                onToggleSign = onToggleSign,
                onBackspace = onBackspace,
                onClear = onClear,
                onSwapUnits = onSwapUnits,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun CategoryChipRow(
    selected: UnitCategory,
    onSelect: (UnitCategory) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        UnitCategory.entries.forEach { category ->
            val isSelected = category == selected
            FilterChip(
                selected = isSelected,
                onClick = { onSelect(category) },
                label = {
                    Text(
                        text = category.displayName,
                        style = MaterialTheme.typography.labelLarge
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier.testTag("converter_cat_${category.name.lowercase()}")
            )
        }
    }
}

@Composable
private fun ConverterCardsPair(
    input: String,
    output: String,
    fromUnit: MeasureUnit,
    toUnit: MeasureUnit,
    units: List<MeasureUnit>,
    onSelectFromUnit: (MeasureUnit) -> Unit,
    onSelectToUnit: (MeasureUnit) -> Unit,
    onSwapUnits: () -> Unit
) {
    val palette = LocalCalculatorPalette.current

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            UnitValueCard(
                label = stringResource(R.string.converter_from),
                valueText = input,
                selectedUnit = fromUnit,
                units = units,
                isPrimaryInput = true,
                onSelectUnit = onSelectFromUnit,
                testTagPrefix = "from"
            )
            UnitValueCard(
                label = stringResource(R.string.converter_to),
                valueText = output,
                selectedUnit = toUnit,
                units = units,
                isPrimaryInput = false,
                onSelectUnit = onSelectToUnit,
                testTagPrefix = "to"
            )
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = palette.equalsKeyBg,
            shadowElevation = 4.dp,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 18.dp)
        ) {
            IconButton(
                onClick = onSwapUnits,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("converter_swap_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.SwapVert,
                    contentDescription = stringResource(R.string.cd_swap_units),
                    tint = palette.equalsKeyText
                )
            }
        }
    }
}

@Composable
private fun UnitValueCard(
    label: String,
    valueText: String,
    selectedUnit: MeasureUnit,
    units: List<MeasureUnit>,
    isPrimaryInput: Boolean,
    onSelectUnit: (MeasureUnit) -> Unit,
    testTagPrefix: String
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val palette = LocalCalculatorPalette.current

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = palette.displayDeck,
        border = BorderStroke(
            width = if (isPrimaryInput) 1.5.dp else 1.dp,
            color = if (isPrimaryInput) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Surface(
                    onClick = { menuExpanded = true },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.testTag("converter_${testTagPrefix}_unit_picker")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${selectedUnit.name} (${selectedUnit.symbol})",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.size(4.dp))
                        Icon(
                            imageVector = Icons.Rounded.ArrowDropDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    units.forEach { unit ->
                        DropdownMenuItem(
                            text = { Text("${unit.name} (${unit.symbol})") },
                            onClick = {
                                onSelectUnit(unit)
                                menuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.size(12.dp))

            Text(
                text = valueText,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = if (valueText.length > 10) 24.sp else 30.sp,
                    fontFeatureSettings = "tnum"
                ),
                color = if (isPrimaryInput) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    palette.operatorKeyText
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 40.dp)
                    .testTag("converter_${testTagPrefix}_value")
            )
        }
    }
}

@Composable
private fun ConverterKeypad(
    hapticsEnabled: Boolean,
    onDigit: (String) -> Unit,
    onDecimal: () -> Unit,
    onToggleSign: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onSwapUnits: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spacing = 10.dp
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(spacing)
    ) {
        // Row 1: 7 8 9 ⌫
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("7", "8", "9").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "conv_key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "⌫",
                icon = Icons.AutoMirrored.Rounded.Backspace,
                contentDescriptionText = stringResource(R.string.cd_backspace),
                role = KeyRole.FUNCTION,
                testTag = "conv_key_backspace",
                onClick = onBackspace,
                onLongClick = onClear,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
        // Row 2: 4 5 6 C
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("4", "5", "6").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "conv_key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "C",
                role = KeyRole.CLEAR,
                testTag = "conv_key_clear",
                onClick = onClear,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
        // Row 3: 1 2 3 Swap
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("1", "2", "3").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "conv_key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "⇅",
                icon = Icons.Rounded.SwapVert,
                contentDescriptionText = stringResource(R.string.cd_swap_units),
                role = KeyRole.OPERATOR,
                testTag = "conv_key_swap",
                onClick = onSwapUnits,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
        // Row 4: +/− 0 00 .
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            TactileKey(
                label = "+/−",
                role = KeyRole.DIGIT,
                testTag = "conv_key_sign",
                onClick = onToggleSign,
                hapticsEnabled = hapticsEnabled,
                textStyle = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "0",
                role = KeyRole.DIGIT,
                testTag = "conv_key_0",
                onClick = { onDigit("0") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "00",
                role = KeyRole.DIGIT,
                testTag = "conv_key_00",
                onClick = { onDigit("00") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = ".",
                role = KeyRole.DIGIT,
                testTag = "conv_key_decimal",
                onClick = onDecimal,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
    }
}

@Composable
fun ConverterReferencePane(
    state: CalculatorUiState,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = stringResource(R.string.converter_quick_reference),
                style = MaterialTheme.typography.titleLarge
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(state.converterAllResults, key = { it.unit.id }) { row ->
                    val isTarget = row.unit.id == state.converterToUnit.id
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isTarget) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${row.unit.name} (${row.unit.symbol})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = row.formattedValue,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontFeatureSettings = "tnum"
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
