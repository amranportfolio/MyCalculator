package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class CalculatorPalette(
    val displayDeck: Color,
    val digitKeyBg: Color,
    val digitKeyText: Color,
    val functionKeyBg: Color,
    val functionKeyText: Color,
    val operatorKeyBg: Color,
    val operatorKeyText: Color,
    val equalsKeyBg: Color,
    val equalsKeyText: Color,
    val clearKeyBg: Color,
    val clearKeyText: Color,
    val sciKeyBg: Color,
    val sciKeyText: Color,
    val ambientGlow: Color
)

val LocalCalculatorPalette = staticCompositionLocalOf {
    DarkCalculatorPalette
}

private val DarkCalculatorPalette = CalculatorPalette(
    displayDeck = ObsidianDeck,
    digitKeyBg = GraphiteKeycap,
    digitKeyText = ObsidianTextPrimary,
    functionKeyBg = GraphiteKeycapElevated,
    functionKeyText = ObsidianTextPrimary,
    operatorKeyBg = ObsidianOperatorBg,
    operatorKeyText = CoralEmberSoft,
    equalsKeyBg = CoralEmber,
    equalsKeyText = Color.White,
    clearKeyBg = ObsidianClearBg,
    clearKeyText = ObsidianClearText,
    sciKeyBg = ObsidianSciBg,
    sciKeyText = ObsidianSciText,
    ambientGlow = CoralEmber.copy(alpha = 0.08f)
)

private val LightCalculatorPalette = CalculatorPalette(
    displayDeck = AlabasterDeck,
    digitKeyBg = AlabasterKeycap,
    digitKeyText = AlabasterTextPrimary,
    functionKeyBg = AlabasterKeycapElevated,
    functionKeyText = AlabasterTextPrimary,
    operatorKeyBg = AlabasterOperatorBg,
    operatorKeyText = CoralEmberDeep,
    equalsKeyBg = CoralEmberDeep,
    equalsKeyText = Color.White,
    clearKeyBg = AlabasterClearBg,
    clearKeyText = AlabasterClearText,
    sciKeyBg = AlabasterSciBg,
    sciKeyText = AlabasterSciText,
    ambientGlow = CoralEmber.copy(alpha = 0.06f)
)

private val DarkColorScheme = darkColorScheme(
    primary = CoralEmber,
    onPrimary = Color.White,
    primaryContainer = ObsidianOperatorBg,
    onPrimaryContainer = CoralEmberSoft,
    secondary = ObsidianSciText,
    onSecondary = ObsidianBackground,
    secondaryContainer = GraphiteKeycapElevated,
    onSecondaryContainer = ObsidianTextPrimary,
    background = ObsidianBackground,
    onBackground = ObsidianTextPrimary,
    surface = ObsidianDeck,
    onSurface = ObsidianTextPrimary,
    surfaceVariant = GraphiteKeycap,
    onSurfaceVariant = ObsidianTextSecondary,
    surfaceContainerHigh = GraphiteKeycapElevated,
    outline = ObsidianOutline,
    errorContainer = ObsidianClearBg,
    onErrorContainer = ObsidianClearText
)

private val LightColorScheme = lightColorScheme(
    primary = CoralEmberDeep,
    onPrimary = Color.White,
    primaryContainer = AlabasterOperatorBg,
    onPrimaryContainer = CoralEmberDeep,
    secondary = AlabasterSciText,
    onSecondary = Color.White,
    secondaryContainer = AlabasterKeycapElevated,
    onSecondaryContainer = AlabasterTextPrimary,
    background = AlabasterBackground,
    onBackground = AlabasterTextPrimary,
    surface = AlabasterDeck,
    onSurface = AlabasterTextPrimary,
    surfaceVariant = AlabasterKeycapElevated,
    onSurfaceVariant = AlabasterTextSecondary,
    surfaceContainerHigh = AlabasterKeycapElevated,
    outline = AlabasterOutline,
    errorContainer = AlabasterClearBg,
    onErrorContainer = AlabasterClearText
)

val CalcShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

enum class ThemeMode {
    SYSTEM, DARK, LIGHT
}

@Composable
fun PrecisionCalcTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val colorScheme = if (isDark) DarkColorScheme else LightColorScheme
    val calcPalette = if (isDark) DarkCalculatorPalette else LightCalculatorPalette

    CompositionLocalProvider(LocalCalculatorPalette provides calcPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CalcTypography,
            shapes = CalcShapes,
            content = content
        )
    }
}
