package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import com.example.ui.theme.LocalCalculatorPalette
import com.example.ui.theme.SpaceGroteskFontFamily

enum class KeyRole {
    DIGIT,
    FUNCTION,
    OPERATOR,
    EQUALS,
    CLEAR,
    SCIENTIFIC
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TactileKey(
    label: String,
    role: KeyRole,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    icon: ImageVector? = null,
    contentDescriptionText: String = label,
    hapticsEnabled: Boolean = true,
    isActiveToggle: Boolean = false,
    shape: Shape = RoundedCornerShape(20.dp),
    textStyle: TextStyle? = null,
    minHeight: Dp = 48.dp
) {
    val palette = LocalCalculatorPalette.current
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.93f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "key_scale"
    )

    val containerColor: Color
    val contentColor: Color
    when (role) {
        KeyRole.DIGIT -> {
            containerColor = palette.digitKeyBg
            contentColor = palette.digitKeyText
        }
        KeyRole.FUNCTION -> {
            containerColor = palette.functionKeyBg
            contentColor = palette.functionKeyText
        }
        KeyRole.OPERATOR -> {
            containerColor = palette.operatorKeyBg
            contentColor = palette.operatorKeyText
        }
        KeyRole.EQUALS -> {
            containerColor = palette.equalsKeyBg
            contentColor = palette.equalsKeyText
        }
        KeyRole.CLEAR -> {
            containerColor = palette.clearKeyBg
            contentColor = palette.clearKeyText
        }
        KeyRole.SCIENTIFIC -> {
            containerColor = if (isActiveToggle) palette.equalsKeyBg else palette.sciKeyBg
            contentColor = if (isActiveToggle) palette.equalsKeyText else palette.sciKeyText
        }
    }

    val borderStroke = when (role) {
        KeyRole.DIGIT -> BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        KeyRole.EQUALS -> null
        else -> BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
    }

    val resolvedStyle = textStyle ?: when (role) {
        KeyRole.DIGIT -> TextStyle(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 24.sp
        )
        KeyRole.OPERATOR, KeyRole.EQUALS -> TextStyle(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 26.sp
        )
        KeyRole.CLEAR, KeyRole.FUNCTION -> TextStyle(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 18.sp
        )
        KeyRole.SCIENTIFIC -> TextStyle(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp
        )
    }

    Surface(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = minHeight)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .testTag(testTag)
            .semantics {
                contentDescription = contentDescriptionText
            }
            .combinedClickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true),
                role = Role.Button,
                onClick = {
                    if (hapticsEnabled) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    onClick()
                },
                onLongClick = onLongClick?.let { longAction ->
                    {
                        if (hapticsEnabled) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        longAction()
                    }
                }
            ),
        shape = shape,
        color = containerColor,
        contentColor = contentColor,
        border = borderStroke,
        tonalElevation = if (role == KeyRole.DIGIT) 1.dp else 0.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(22.dp)
                )
            } else {
                Text(
                    text = label,
                    style = resolvedStyle,
                    color = contentColor,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Clip
                )
            }
        }
    }
}
