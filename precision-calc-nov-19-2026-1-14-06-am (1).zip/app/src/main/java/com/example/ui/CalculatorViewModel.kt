package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CalculatorRepository
import com.example.domain.AngleMode
import com.example.domain.CalcErrorType
import com.example.domain.CalculatorEngine
import com.example.domain.EvalResult
import com.example.domain.HistoryItem
import com.example.domain.MeasureUnit
import com.example.domain.UnitCategory
import com.example.domain.UnitConverter
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.util.UUID

enum class AppMode {
    CALCULATOR,
    CONVERTER
}

data class ConverterConversionRow(
    val unit: MeasureUnit,
    val formattedValue: String
)

data class CalculatorUiState(
    val appMode: AppMode = AppMode.CALCULATOR,
    val expression: String = "",
    val previousExpression: String = "",
    val livePreview: String = "",
    val errorType: CalcErrorType? = null,
    val justEvaluated: Boolean = false,
    val isScientificExpanded: Boolean = false,
    val isInverseMode: Boolean = false,
    val angleMode: AngleMode = AngleMode.DEG,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val hapticsEnabled: Boolean = true,
    val memoryValue: BigDecimal = BigDecimal.ZERO,
    val lastAns: BigDecimal = BigDecimal.ZERO,
    val history: List<HistoryItem> = emptyList(),
    // Converter state
    val converterCategory: UnitCategory = UnitCategory.LENGTH,
    val converterFromUnit: MeasureUnit = UnitConverter.unitsByCategory[UnitCategory.LENGTH]!!.first(),
    val converterToUnit: MeasureUnit = UnitConverter.unitsByCategory[UnitCategory.LENGTH]!![1],
    val converterInput: String = "1",
    val converterOutput: String = "0.001",
    val converterAllResults: List<ConverterConversionRow> = emptyList()
) {
    val hasMemory: Boolean
        get() = memoryValue.compareTo(BigDecimal.ZERO) != 0
}

sealed interface UiEvent {
    data class ShowMessage(val text: String) : UiEvent
}

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CalculatorRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    private val multiCharTokens = listOf(
        "sin⁻¹(", "cos⁻¹(", "tan⁻¹(",
        "sin(", "cos(", "tan(",
        "sqrt(", "log(", "ln(",
        "√(", "Ans"
    )

    init {
        recomputeConverter()
        viewModelScope.launch {
            repository.preferencesFlow.collect { prefs ->
                val memBd = prefs.memoryValue.toBigDecimalOrNull() ?: BigDecimal.ZERO
                val ansBd = prefs.lastAns.toBigDecimalOrNull() ?: BigDecimal.ZERO
                _uiState.update { state ->
                    state.copy(
                        history = prefs.history,
                        angleMode = prefs.angleMode,
                        themeMode = prefs.themeMode,
                        hapticsEnabled = prefs.hapticsEnabled,
                        memoryValue = memBd,
                        lastAns = ansBd
                    )
                }
                refreshLivePreview()
            }
        }
    }

    fun switchAppMode(mode: AppMode) {
        _uiState.update { it.copy(appMode = mode) }
    }

    fun toggleScientific() {
        _uiState.update { it.copy(isScientificExpanded = !it.isScientificExpanded) }
    }

    fun toggleInverse() {
        _uiState.update { it.copy(isInverseMode = !it.isInverseMode) }
    }

    fun toggleAngleMode() {
        val next = if (_uiState.value.angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
        _uiState.update { it.copy(angleMode = next) }
        refreshLivePreview()
        viewModelScope.launch { repository.setAngleMode(next) }
    }

    fun setThemeMode(mode: ThemeMode) {
        _uiState.update { it.copy(themeMode = mode) }
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        _uiState.update { it.copy(hapticsEnabled = enabled) }
        viewModelScope.launch { repository.setHapticsEnabled(enabled) }
    }

    fun appendDigit(digit: String) {
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            val next = if (base == "0" && digit != "00") {
                digit
            } else if (base == "0" && digit == "00") {
                "0"
            } else {
                base + digit
            }
            state.copy(
                expression = next,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                errorType = null,
                justEvaluated = false
            )
        }
        refreshLivePreview()
    }

    fun appendDecimal() {
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            val currentSegment = extractTrailingNumber(base)
            if (currentSegment.contains('.')) {
                return@update state
            }
            val needsLeadingZero = base.isEmpty() || !base.last().isDigit()
            val next = if (needsLeadingZero) "${base}0." else "$base."
            state.copy(
                expression = next,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                errorType = null,
                justEvaluated = false
            )
        }
        refreshLivePreview()
    }

    fun appendOperator(op: String) {
        _uiState.update { state ->
            if (state.errorType != null) return@update state
            val base = if (state.justEvaluated) {
                CalculatorEngine.formatRawPlain(state.lastAns)
            } else {
                state.expression
            }

            if (base.isEmpty()) {
                return@update if (op == "−") {
                    state.copy(expression = "−", justEvaluated = false, errorType = null)
                } else {
                    state
                }
            }

            val lastChar = base.last()
            val binaryOps = setOf('+', '−', '×', '÷', '^')

            val next = when {
                lastChar == '(' -> {
                    if (op == "−") "$base−" else base
                }
                lastChar in binaryOps -> {
                    if (op == "−" && lastChar in setOf('×', '÷', '^')) {
                        "$base−"
                    } else if (base.length >= 2 && lastChar == '−' && base[base.length - 2] in setOf('×', '÷', '^', '(')) {
                        if (op == "−") base else base.dropLast(2) + op
                    } else {
                        base.dropLast(1) + op
                    }
                }
                else -> base + op
            }

            state.copy(
                expression = next,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun appendPostfix(symbol: String) {
        _uiState.update { state ->
            if (state.errorType != null) return@update state
            val base = if (state.justEvaluated) {
                CalculatorEngine.formatRawPlain(state.lastAns)
            } else {
                state.expression
            }
            if (base.isEmpty()) return@update state
            val last = base.last()
            val validPrev = last.isDigit() || last == ')' || last == 'π' || last == 'e' || last == 's' || last == '%' || last == '!'
            if (!validPrev) return@update state
            state.copy(
                expression = base + symbol,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun appendFunction(funcPrefix: String) {
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            state.copy(
                expression = base + funcPrefix,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun appendConstant(constant: String) {
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            state.copy(
                expression = base + constant,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun appendSquare() {
        appendOperator("^")
        _uiState.update { it.copy(expression = it.expression + "2") }
        refreshLivePreview()
    }

    fun appendReciprocal() {
        _uiState.update { state ->
            if (state.errorType != null) return@update state
            val base = if (state.justEvaluated) {
                CalculatorEngine.formatRawPlain(state.lastAns)
            } else {
                state.expression
            }
            val next = if (base.isEmpty()) "1÷(" else "1÷($base)"
            state.copy(
                expression = next,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun appendParen(paren: String) {
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            if (paren == ")") {
                val openCount = base.count { it == '(' }
                val closeCount = base.count { it == ')' }
                if (openCount <= closeCount) return@update state
                val last = base.lastOrNull() ?: return@update state
                if (last in setOf('(', '+', '−', '×', '÷', '^')) return@update state
            }
            state.copy(
                expression = base + paren,
                previousExpression = if (state.justEvaluated) "" else state.previousExpression,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun toggleSmartParen() {
        val expr = if (_uiState.value.justEvaluated || _uiState.value.errorType != null) "" else _uiState.value.expression
        val openCount = expr.count { it == '(' }
        val closeCount = expr.count { it == ')' }
        val last = expr.lastOrNull()
        val canClose = openCount > closeCount && last != null &&
            (last.isDigit() || last == ')' || last == 'π' || last == 'e' || last == 's' || last == '%' || last == '!')
        appendParen(if (canClose) ")" else "(")
    }

    fun toggleSign() {
        _uiState.update { state ->
            if (state.errorType != null) return@update state
            val expr = if (state.justEvaluated) {
                CalculatorEngine.formatRawPlain(state.lastAns)
            } else {
                state.expression
            }
            if (expr.isEmpty()) {
                return@update state.copy(expression = "−", justEvaluated = false)
            }
            // Toggle wrapped negative like (−123) at tail
            val wrappedNegRegex = Regex("""\(−(\d*\.?\d+)\)$""")
            val wrappedMatch = wrappedNegRegex.find(expr)
            if (wrappedMatch != null) {
                val num = wrappedMatch.groupValues[1]
                val replaced = expr.substring(0, wrappedMatch.range.first) + num
                return@update state.copy(expression = replaced, justEvaluated = false)
            }

            // Toggle leading negative number
            if (expr.startsWith("−") && expr.drop(1).all { it.isDigit() || it == '.' }) {
                return@update state.copy(expression = expr.drop(1), justEvaluated = false)
            }
            if (expr.all { it.isDigit() || it == '.' }) {
                return@update state.copy(expression = "−$expr", justEvaluated = false)
            }

            // Wrap trailing number in (−x)
            val tailNumRegex = Regex("""(\d*\.?\d+)$""")
            val tailMatch = tailNumRegex.find(expr)
            if (tailMatch != null) {
                val num = tailMatch.groupValues[1]
                val replaced = expr.substring(0, tailMatch.range.first) + "(−$num)"
                return@update state.copy(expression = replaced, justEvaluated = false)
            }

            state
        }
        refreshLivePreview()
    }

    fun backspace() {
        _uiState.update { state ->
            if (state.errorType != null) {
                return@update state.copy(errorType = null, livePreview = "")
            }
            val expr = state.expression
            if (expr.isEmpty()) return@update state

            val matchedPrefix = multiCharTokens.firstOrNull { expr.endsWith(it) }
            val next = if (matchedPrefix != null) {
                expr.dropLast(matchedPrefix.length)
            } else {
                expr.dropLast(1)
            }
            state.copy(
                expression = next,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun clearAll() {
        _uiState.update {
            it.copy(
                expression = "",
                previousExpression = "",
                livePreview = "",
                errorType = null,
                justEvaluated = false
            )
        }
    }

    fun evaluate() {
        val state = _uiState.value
        if (state.expression.isBlank()) return

        when (val res = CalculatorEngine.evaluate(state.expression, state.angleMode, state.lastAns)) {
            is EvalResult.Success -> {
                val historyItem = HistoryItem(
                    id = UUID.randomUUID().toString(),
                    expression = state.expression,
                    result = res.formatted,
                    timestampMillis = System.currentTimeMillis()
                )
                val rawPlain = CalculatorEngine.formatRawPlain(res.value)
                _uiState.update {
                    it.copy(
                        previousExpression = state.expression,
                        expression = res.formatted,
                        livePreview = "",
                        errorType = null,
                        justEvaluated = true,
                        lastAns = res.value
                    )
                }
                viewModelScope.launch {
                    repository.addHistoryItem(historyItem, rawPlain)
                }
            }
            is EvalResult.Error -> {
                _uiState.update {
                    it.copy(
                        errorType = res.type,
                        livePreview = ""
                    )
                }
            }
        }
    }

    fun memoryClear(message: String) {
        _uiState.update { it.copy(memoryValue = BigDecimal.ZERO) }
        viewModelScope.launch {
            repository.setMemoryValue("0")
            _events.emit(UiEvent.ShowMessage(message))
        }
    }

    fun memoryRecall() {
        val memStr = CalculatorEngine.formatRawPlain(_uiState.value.memoryValue)
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            state.copy(
                expression = base + memStr,
                justEvaluated = false,
                errorType = null
            )
        }
        refreshLivePreview()
    }

    fun memoryAdd(message: String) {
        val currentVal = resolveCurrentNumericValue() ?: return
        val updated = _uiState.value.memoryValue.add(currentVal)
        _uiState.update { it.copy(memoryValue = updated) }
        viewModelScope.launch {
            repository.setMemoryValue(CalculatorEngine.formatRawPlain(updated))
            _events.emit(UiEvent.ShowMessage(message))
        }
    }

    fun memorySubtract(message: String) {
        val currentVal = resolveCurrentNumericValue() ?: return
        val updated = _uiState.value.memoryValue.subtract(currentVal)
        _uiState.update { it.copy(memoryValue = updated) }
        viewModelScope.launch {
            repository.setMemoryValue(CalculatorEngine.formatRawPlain(updated))
            _events.emit(UiEvent.ShowMessage(message))
        }
    }

    fun useHistoryExpression(item: HistoryItem) {
        _uiState.update {
            it.copy(
                expression = item.expression,
                previousExpression = "",
                justEvaluated = false,
                errorType = null,
                appMode = AppMode.CALCULATOR
            )
        }
        refreshLivePreview()
    }

    fun useHistoryResult(item: HistoryItem) {
        val cleanResult = item.result.replace(",", "")
        _uiState.update { state ->
            val base = if (state.justEvaluated || state.errorType != null) "" else state.expression
            state.copy(
                expression = base + cleanResult,
                justEvaluated = false,
                errorType = null,
                appMode = AppMode.CALCULATOR
            )
        }
        refreshLivePreview()
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch {
            repository.deleteHistoryItem(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun notifyMessage(message: String) {
        viewModelScope.launch {
            _events.emit(UiEvent.ShowMessage(message))
        }
    }

    // --- Unit Converter Actions ---

    fun selectConverterCategory(category: UnitCategory) {
        val units = UnitConverter.unitsByCategory[category].orEmpty()
        if (units.size < 2) return
        _uiState.update {
            it.copy(
                converterCategory = category,
                converterFromUnit = units[0],
                converterToUnit = units[1]
            )
        }
        recomputeConverter()
    }

    fun selectConverterFromUnit(unit: MeasureUnit) {
        _uiState.update { it.copy(converterFromUnit = unit) }
        recomputeConverter()
    }

    fun selectConverterToUnit(unit: MeasureUnit) {
        _uiState.update { it.copy(converterToUnit = unit) }
        recomputeConverter()
    }

    fun swapConverterUnits() {
        _uiState.update { state ->
            state.copy(
                converterFromUnit = state.converterToUnit,
                converterToUnit = state.converterFromUnit
            )
        }
        recomputeConverter()
    }

    fun converterAppendDigit(digit: String) {
        _uiState.update { state ->
            val curr = state.converterInput
            val next = when {
                curr == "0" && digit == "00" -> "0"
                curr == "0" -> digit
                curr == "-0" -> "-$digit"
                curr.length >= 15 -> curr
                else -> curr + digit
            }
            state.copy(converterInput = next)
        }
        recomputeConverter()
    }

    fun converterAppendDecimal() {
        _uiState.update { state ->
            if (state.converterInput.contains('.')) return@update state
            state.copy(converterInput = state.converterInput + ".")
        }
        recomputeConverter()
    }

    fun converterToggleSign() {
        _uiState.update { state ->
            val curr = state.converterInput
            val next = if (curr.startsWith("-")) curr.drop(1) else "-$curr"
            state.copy(converterInput = next)
        }
        recomputeConverter()
    }

    fun converterBackspace() {
        _uiState.update { state ->
            val curr = state.converterInput
            val next = if (curr.length <= 1 || (curr.length == 2 && curr.startsWith("-"))) {
                "0"
            } else {
                curr.dropLast(1)
            }
            state.copy(converterInput = next)
        }
        recomputeConverter()
    }

    fun converterClear() {
        _uiState.update { it.copy(converterInput = "0") }
        recomputeConverter()
    }

    private fun recomputeConverter() {
        val state = _uiState.value
        val numericInput = state.converterInput.toDoubleOrNull() ?: 0.0
        val outVal = UnitConverter.convert(
            value = numericInput,
            category = state.converterCategory,
            from = state.converterFromUnit,
            to = state.converterToUnit
        )
        val allUnits = UnitConverter.unitsByCategory[state.converterCategory].orEmpty()
        val rows = allUnits.map { unit ->
            val converted = UnitConverter.convert(
                value = numericInput,
                category = state.converterCategory,
                from = state.converterFromUnit,
                to = unit
            )
            ConverterConversionRow(
                unit = unit,
                formattedValue = UnitConverter.formatConverted(converted)
            )
        }
        _uiState.update {
            it.copy(
                converterOutput = UnitConverter.formatConverted(outVal),
                converterAllResults = rows
            )
        }
    }

    private fun refreshLivePreview() {
        val state = _uiState.value
        val expr = state.expression
        if (expr.isBlank() || state.justEvaluated || !hasEvaluatableOperation(expr)) {
            _uiState.update { it.copy(livePreview = "") }
            return
        }
        val eval = CalculatorEngine.evaluate(expr, state.angleMode, state.lastAns)
        _uiState.update {
            it.copy(
                livePreview = if (eval is EvalResult.Success) eval.formatted else ""
            )
        }
    }

    private fun resolveCurrentNumericValue(): BigDecimal? {
        val state = _uiState.value
        if (state.expression.isBlank()) return state.lastAns
        return when (val res = CalculatorEngine.evaluate(state.expression, state.angleMode, state.lastAns)) {
            is EvalResult.Success -> res.value
            is EvalResult.Error -> null
        }
    }

    private fun hasEvaluatableOperation(expr: String): Boolean {
        return expr.any { it in setOf('+', '−', '×', '÷', '^', '%', '!', '(', 'π', '√') } ||
            expr.contains("sin") || expr.contains("cos") || expr.contains("tan") ||
            expr.contains("ln") || expr.contains("log") || expr.contains("e") || expr.contains("Ans")
    }

    private fun extractTrailingNumber(expr: String): String {
        var idx = expr.length - 1
        while (idx >= 0 && (expr[idx].isDigit() || expr[idx] == '.')) {
            idx--
        }
        return expr.substring(idx + 1)
    }
}
