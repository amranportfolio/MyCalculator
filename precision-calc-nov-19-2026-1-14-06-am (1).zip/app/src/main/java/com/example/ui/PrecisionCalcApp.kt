package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.calculator.AnimatedScientificDrawer
import com.example.ui.calculator.MemoryAndQuickSciBar
import com.example.ui.calculator.QuickFunctionsStrip
import com.example.ui.calculator.ScientificKeypadGrid
import com.example.ui.calculator.StandardKeypadGrid
import com.example.ui.components.DisplayDeck
import com.example.ui.components.HistoryPaneContent
import com.example.ui.components.SettingsDialog
import com.example.ui.converter.UnitConverterScreen
import com.example.ui.theme.PrecisionCalcTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrecisionCalcApp(viewModel: CalculatorViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showHistorySheet by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val copiedMsg = stringResource(R.string.copied_to_clipboard)
    val memoryUpdatedMsg = stringResource(R.string.memory_updated)
    val memoryClearedMsg = stringResource(R.string.memory_cleared)

    if (state.appMode == AppMode.CONVERTER) {
        BackHandler {
            viewModel.switchAppMode(AppMode.CALCULATOR)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is UiEvent.ShowMessage -> {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    snackbarHostState.showSnackbar(event.text)
                }
            }
        }
    }

    PrecisionCalcTheme(themeMode = state.themeMode) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                val isExpandedWidth = maxWidth >= 720.dp
                val isLandscapeCompact = maxWidth > maxHeight && maxHeight < 500.dp

                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TopModeHeader(
                        appMode = state.appMode,
                        showHistoryButton = !isExpandedWidth && state.appMode == AppMode.CALCULATOR,
                        onSwitchMode = viewModel::switchAppMode,
                        onOpenHistory = { showHistorySheet = true },
                        onOpenSettings = { showSettingsDialog = true }
                    )

                    if (state.appMode == AppMode.CONVERTER) {
                        UnitConverterScreen(
                            state = state,
                            isWideLayout = isExpandedWidth || isLandscapeCompact,
                            onSelectCategory = viewModel::selectConverterCategory,
                            onSelectFromUnit = viewModel::selectConverterFromUnit,
                            onSelectToUnit = viewModel::selectConverterToUnit,
                            onSwapUnits = viewModel::swapConverterUnits,
                            onDigit = viewModel::converterAppendDigit,
                            onDecimal = viewModel::converterAppendDecimal,
                            onToggleSign = viewModel::converterToggleSign,
                            onBackspace = viewModel::converterBackspace,
                            onClear = viewModel::converterClear,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        CalculatorWorkspace(
                            state = state,
                            isExpandedWidth = isExpandedWidth,
                            isLandscapeCompact = isLandscapeCompact,
                            viewModel = viewModel,
                            onCopyResult = {
                                val textToCopy = state.livePreview.ifEmpty { state.expression }
                                if (textToCopy.isNotEmpty()) {
                                    copyToClipboard(context, textToCopy)
                                    viewModel.notifyMessage(copiedMsg)
                                }
                            },
                            onMemoryClear = { viewModel.memoryClear(memoryClearedMsg) },
                            onMemoryAdd = { viewModel.memoryAdd(memoryUpdatedMsg) },
                            onMemorySubtract = { viewModel.memorySubtract(memoryUpdatedMsg) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (showHistorySheet) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { showHistorySheet = false },
                sheetState = sheetState,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(460.dp)
                ) {
                    HistoryPaneContent(
                        history = state.history,
                        onUseExpression = {
                            viewModel.useHistoryExpression(it)
                            showHistorySheet = false
                        },
                        onUseResult = {
                            viewModel.useHistoryResult(it)
                            showHistorySheet = false
                        },
                        onDeleteItem = viewModel::deleteHistoryItem,
                        onClearAll = viewModel::clearHistory,
                        onClose = { showHistorySheet = false }
                    )
                }
            }
        }

        if (showSettingsDialog) {
            SettingsDialog(
                themeMode = state.themeMode,
                angleMode = state.angleMode,
                hapticsEnabled = state.hapticsEnabled,
                onSelectTheme = viewModel::setThemeMode,
                onToggleAngleMode = viewModel::toggleAngleMode,
                onToggleHaptics = viewModel::setHapticsEnabled,
                onDismiss = { showSettingsDialog = false }
            )
        }
    }
}

@Composable
private fun TopModeHeader(
    appMode: AppMode,
    showHistoryButton: Boolean,
    onSwitchMode: (AppMode) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        ) {
            Row(
                modifier = Modifier.padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ModePillTab(
                    selected = appMode == AppMode.CALCULATOR,
                    label = stringResource(R.string.mode_calculator),
                    icon = Icons.Rounded.Calculate,
                    testTag = "tab_calculator",
                    onClick = { onSwitchMode(AppMode.CALCULATOR) }
                )
                ModePillTab(
                    selected = appMode == AppMode.CONVERTER,
                    label = stringResource(R.string.mode_converter),
                    icon = Icons.Rounded.Straighten,
                    testTag = "tab_converter",
                    onClick = { onSwitchMode(AppMode.CONVERTER) }
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showHistoryButton) {
                IconButton(
                    onClick = onOpenHistory,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("history_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.History,
                        contentDescription = stringResource(R.string.cd_history),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = stringResource(R.string.cd_settings),
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

@Composable
private fun ModePillTab(
    selected: Boolean,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        },
        modifier = Modifier
            .height(40.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (selected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
        }
    }
}

@Composable
private fun CalculatorWorkspace(
    state: CalculatorUiState,
    isExpandedWidth: Boolean,
    isLandscapeCompact: Boolean,
    viewModel: CalculatorViewModel,
    onCopyResult: () -> Unit,
    onMemoryClear: () -> Unit,
    onMemoryAdd: () -> Unit,
    onMemorySubtract: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isExpandedWidth) {
        // Canonical Supporting Pane Layout for tablets / wide screens
        Row(
            modifier = modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1.35f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DisplayDeck(
                    expression = state.expression,
                    previousExpression = state.previousExpression,
                    livePreview = state.livePreview,
                    errorType = state.errorType,
                    angleMode = state.angleMode,
                    hasMemory = state.hasMemory,
                    justEvaluated = state.justEvaluated,
                    onToggleAngleMode = viewModel::toggleAngleMode,
                    onCopyResult = onCopyResult,
                    compactHeight = isLandscapeCompact
                )

                MemoryAndQuickSciBar(
                    state = state,
                    showSciToggle = false,
                    onMemoryClear = onMemoryClear,
                    onMemoryRecall = viewModel::memoryRecall,
                    onMemoryAdd = onMemoryAdd,
                    onMemorySubtract = onMemorySubtract,
                    onToggleScientific = viewModel::toggleScientific,
                    hapticsEnabled = state.hapticsEnabled
                )

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    ScientificKeypadGrid(
                        isInverseMode = state.isInverseMode,
                        hapticsEnabled = state.hapticsEnabled,
                        onToggleInverse = viewModel::toggleInverse,
                        onFunction = viewModel::appendFunction,
                        onConstant = viewModel::appendConstant,
                        onSquare = viewModel::appendSquare,
                        onPower = { viewModel.appendOperator("^") },
                        onFactorial = { viewModel.appendPostfix("!") },
                        onReciprocal = viewModel::appendReciprocal,
                        onParen = viewModel::appendParen,
                        rowHeight = 56.dp,
                        modifier = Modifier.weight(1f)
                    )

                    StandardKeypadGrid(
                        hapticsEnabled = state.hapticsEnabled,
                        onDigit = viewModel::appendDigit,
                        onDecimal = viewModel::appendDecimal,
                        onOperator = viewModel::appendOperator,
                        onPercent = { viewModel.appendPostfix("%") },
                        onToggleSign = viewModel::toggleSign,
                        onBackspace = viewModel::backspace,
                        onClearAll = viewModel::clearAll,
                        onEvaluate = viewModel::evaluate,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
            }

            // Right Supporting Pane: Live Calculation Tape
            Surface(
                modifier = Modifier
                    .weight(0.75f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                HistoryPaneContent(
                    history = state.history,
                    onUseExpression = viewModel::useHistoryExpression,
                    onUseResult = viewModel::useHistoryResult,
                    onDeleteItem = viewModel::deleteHistoryItem,
                    onClearAll = viewModel::clearHistory,
                    onClose = null
                )
            }
        }
    } else if (isLandscapeCompact) {
        // Landscape phone layout: Display on top, Scientific & Standard keypads side-by-side
        Column(
            modifier = modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DisplayDeck(
                expression = state.expression,
                previousExpression = state.previousExpression,
                livePreview = state.livePreview,
                errorType = state.errorType,
                angleMode = state.angleMode,
                hasMemory = state.hasMemory,
                justEvaluated = state.justEvaluated,
                onToggleAngleMode = viewModel::toggleAngleMode,
                onCopyResult = onCopyResult,
                compactHeight = true
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                ScientificKeypadGrid(
                    isInverseMode = state.isInverseMode,
                    hapticsEnabled = state.hapticsEnabled,
                    onToggleInverse = viewModel::toggleInverse,
                    onFunction = viewModel::appendFunction,
                    onConstant = viewModel::appendConstant,
                    onSquare = viewModel::appendSquare,
                    onPower = { viewModel.appendOperator("^") },
                    onFactorial = { viewModel.appendPostfix("!") },
                    onReciprocal = viewModel::appendReciprocal,
                    onParen = viewModel::appendParen,
                    rowHeight = 48.dp,
                    modifier = Modifier.weight(0.95f)
                )

                StandardKeypadGrid(
                    hapticsEnabled = state.hapticsEnabled,
                    onDigit = viewModel::appendDigit,
                    onDecimal = viewModel::appendDecimal,
                    onOperator = viewModel::appendOperator,
                    onPercent = { viewModel.appendPostfix("%") },
                    onToggleSign = viewModel::toggleSign,
                    onBackspace = viewModel::backspace,
                    onClearAll = viewModel::clearAll,
                    onEvaluate = viewModel::evaluate,
                    spacing = 6.dp,
                    modifier = Modifier
                        .weight(1.05f)
                        .fillMaxHeight()
                )
            }
        }
    } else {
        // Portrait Handheld Layout (Primary Mobile Experience)
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DisplayDeck(
                    expression = state.expression,
                    previousExpression = state.previousExpression,
                    livePreview = state.livePreview,
                    errorType = state.errorType,
                    angleMode = state.angleMode,
                    hasMemory = state.hasMemory,
                    justEvaluated = state.justEvaluated,
                    onToggleAngleMode = viewModel::toggleAngleMode,
                    onCopyResult = onCopyResult,
                    modifier = Modifier.weight(
                        if (state.isScientificExpanded) 0.30f else 0.36f
                    )
                )

                MemoryAndQuickSciBar(
                    state = state,
                    showSciToggle = true,
                    onMemoryClear = onMemoryClear,
                    onMemoryRecall = viewModel::memoryRecall,
                    onMemoryAdd = onMemoryAdd,
                    onMemorySubtract = onMemorySubtract,
                    onToggleScientific = viewModel::toggleScientific,
                    hapticsEnabled = state.hapticsEnabled
                )

                if (!state.isScientificExpanded) {
                    QuickFunctionsStrip(
                        onOpenParen = { viewModel.appendParen("(") },
                        onCloseParen = { viewModel.appendParen(")") },
                        onSqrt = { viewModel.appendFunction("√(") },
                        onPower = { viewModel.appendOperator("^") },
                        onPi = { viewModel.appendConstant("π") },
                        hapticsEnabled = state.hapticsEnabled
                    )
                }

                AnimatedScientificDrawer(visible = state.isScientificExpanded) {
                    ScientificKeypadGrid(
                        isInverseMode = state.isInverseMode,
                        hapticsEnabled = state.hapticsEnabled,
                        onToggleInverse = viewModel::toggleInverse,
                        onFunction = viewModel::appendFunction,
                        onConstant = viewModel::appendConstant,
                        onSquare = viewModel::appendSquare,
                        onPower = { viewModel.appendOperator("^") },
                        onFactorial = { viewModel.appendPostfix("!") },
                        onReciprocal = viewModel::appendReciprocal,
                        onParen = viewModel::appendParen,
                        rowHeight = 48.dp
                    )
                }

                StandardKeypadGrid(
                    hapticsEnabled = state.hapticsEnabled,
                    onDigit = viewModel::appendDigit,
                    onDecimal = viewModel::appendDecimal,
                    onOperator = viewModel::appendOperator,
                    onPercent = { viewModel.appendPostfix("%") },
                    onToggleSign = viewModel::toggleSign,
                    onBackspace = viewModel::backspace,
                    onClearAll = viewModel::clearAll,
                    onEvaluate = viewModel::evaluate,
                    modifier = Modifier
                        .weight(if (state.isScientificExpanded) 0.56f else 0.64f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText("Calculator Result", text))
}
