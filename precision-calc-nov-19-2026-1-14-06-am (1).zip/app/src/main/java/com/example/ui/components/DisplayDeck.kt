package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.AngleMode
import com.example.domain.CalcErrorType
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCalculatorPalette

@Composable
fun DisplayDeck(
    expression: String,
    previousExpression: String,
    livePreview: String,
    errorType: CalcErrorType?,
    angleMode: AngleMode,
    hasMemory: Boolean,
    justEvaluated: Boolean,
    onToggleAngleMode: () -> Unit,
    onCopyResult: () -> Unit,
    modifier: Modifier = Modifier,
    compactHeight: Boolean = false
) {
    val palette = LocalCalculatorPalette.current
    val scrollState = rememberScrollState()

    LaunchedEffect(expression) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    val errorMessage = when (errorType) {
        CalcErrorType.DIVIDE_BY_ZERO -> stringResource(R.string.error_divide_zero)
        CalcErrorType.DOMAIN -> stringResource(R.string.error_domain)
        CalcErrorType.SYNTAX -> stringResource(R.string.error_syntax)
        CalcErrorType.OVERFLOW -> stringResource(R.string.error_overflow)
        null -> null
    }

    val displayLength = expression.length
    val primaryFontSize = when {
        compactHeight && displayLength > 14 -> 26.sp
        compactHeight -> 34.sp
        displayLength > 18 -> 28.sp
        displayLength > 13 -> 36.sp
        displayLength > 9 -> 44.sp
        else -> 52.sp
    }

    val operatorColor = palette.operatorKeyText
    val sciColor = palette.sciKeyText
    val primaryTextColor = MaterialTheme.colorScheme.onSurface

    val styledExpression = remember(expression, operatorColor, sciColor, primaryTextColor) {
        buildStyledExpression(
            expr = expression.ifEmpty { "0" },
            baseColor = if (expression.isEmpty()) primaryTextColor.copy(alpha = 0.38f) else primaryTextColor,
            operatorColor = operatorColor,
            sciColor = sciColor
        )
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = palette.displayDeck,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(palette.ambientGlow, Color.Transparent),
                            center = Offset(size.width * 0.88f, size.height * 0.82f),
                            radius = size.maxDimension * 0.7f
                        )
                    )
                }
                .padding(
                    horizontal = 18.dp,
                    vertical = if (compactHeight) 10.dp else 14.dp
                ),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Strip: DEG/RAD chip, M indicator, Copy button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = onToggleAngleMode,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("angle_mode_toggle"),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                        )
                    ) {
                        Text(
                            text = if (angleMode == AngleMode.DEG) {
                                stringResource(R.string.angle_deg)
                            } else {
                                stringResource(R.string.angle_rad)
                            },
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = JetBrainsMonoFontFamily
                            ),
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    AnimatedVisibility(
                        visible = hasMemory,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = palette.operatorKeyBg
                        ) {
                            Text(
                                text = stringResource(R.string.memory_indicator),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = JetBrainsMonoFontFamily
                                ),
                                color = palette.operatorKeyText,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                if (expression.isNotEmpty() && errorType == null) {
                    IconButton(
                        onClick = onCopyResult,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("copy_result_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = stringResource(R.string.cd_copy_result),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.height(48.dp))
                }
            }

            // Previous solved expression tape line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = if (compactHeight) 18.dp else 22.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                if (previousExpression.isNotEmpty()) {
                    Text(
                        text = "$previousExpression =",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontFeatureSettings = "tnum"
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.End
                    )
                }
            }

            // Main Expression / Result Readout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(vertical = if (compactHeight) 2.dp else 6.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    text = styledExpression,
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = primaryFontSize,
                        lineHeight = primaryFontSize * 1.12f,
                        fontWeight = if (justEvaluated) FontWeight.Bold else FontWeight.Medium
                    ),
                    maxLines = 1,
                    softWrap = false,
                    textAlign = TextAlign.End,
                    modifier = Modifier.testTag("calculator_display_text")
                )
            }

            // Bottom Preview / Error Line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = if (compactHeight) 24.dp else 30.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                .testTag("calculator_error_text")
                        )
                    }
                } else if (livePreview.isNotEmpty()) {
                    Text(
                        text = "= $livePreview",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = if (compactHeight) 18.sp else 22.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontFeatureSettings = "tnum"
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.testTag("calculator_preview_text")
                    )
                }
            }
        }
    }
}

private fun buildStyledExpression(
    expr: String,
    baseColor: Color,
    operatorColor: Color,
    sciColor: Color
): AnnotatedString {
    val operators = setOf('+', '−', '×', '÷', '^', '%', '!')
    val parens = setOf('(', ')')
    return buildAnnotatedString {
        append(expr)
        addStyle(SpanStyle(color = baseColor), 0, expr.length)
        expr.forEachIndexed { index, ch ->
            when {
                ch in operators -> addStyle(
                    SpanStyle(color = operatorColor, fontWeight = FontWeight.SemiBold),
                    index,
                    index + 1
                )
                ch in parens || ch == 'π' || ch == '√' -> addStyle(
                    SpanStyle(color = sciColor),
                    index,
                    index + 1
                )
            }
        }
    }
}
