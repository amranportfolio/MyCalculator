package com.example.ui.calculator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.CalculatorUiState
import com.example.ui.components.KeyRole
import com.example.ui.components.TactileKey
import com.example.ui.theme.LocalCalculatorPalette

@Composable
fun MemoryAndQuickSciBar(
    state: CalculatorUiState,
    showSciToggle: Boolean,
    onMemoryClear: () -> Unit,
    onMemoryRecall: () -> Unit,
    onMemoryAdd: () -> Unit,
    onMemorySubtract: () -> Unit,
    onToggleScientific: () -> Unit,
    hapticsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val palette = LocalCalculatorPalette.current
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val memoryKeys = listOf(
            Triple("MC", "key_mc", onMemoryClear),
            Triple("MR", "key_mr", onMemoryRecall),
            Triple("M+", "key_m_plus", onMemoryAdd),
            Triple("M−", "key_m_minus", onMemorySubtract)
        )
        memoryKeys.forEach { (label, tag, action) ->
            TactileKey(
                label = label,
                role = KeyRole.FUNCTION,
                testTag = tag,
                onClick = action,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                minHeight = 48.dp,
                textStyle = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            )
        }

        if (showSciToggle) {
            Surface(
                onClick = onToggleScientific,
                shape = RoundedCornerShape(14.dp),
                color = if (state.isScientificExpanded) {
                    palette.equalsKeyBg
                } else {
                    palette.sciKeyBg
                },
                modifier = Modifier
                    .weight(1.15f)
                    .height(48.dp)
                    .testTag("key_sci_toggle")
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.sci_label),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (state.isScientificExpanded) {
                            palette.equalsKeyText
                        } else {
                            palette.sciKeyText
                        }
                    )
                    Icon(
                        imageVector = if (state.isScientificExpanded) {
                            Icons.Rounded.ExpandLess
                        } else {
                            Icons.Rounded.ExpandMore
                        },
                        contentDescription = stringResource(R.string.cd_toggle_scientific),
                        tint = if (state.isScientificExpanded) {
                            palette.equalsKeyText
                        } else {
                            palette.sciKeyText
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun QuickFunctionsStrip(
    onOpenParen: () -> Unit,
    onCloseParen: () -> Unit,
    onSqrt: () -> Unit,
    onPower: () -> Unit,
    onPi: () -> Unit,
    hapticsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TactileKey(
            label = "(",
            role = KeyRole.SCIENTIFIC,
            testTag = "key_open_paren",
            onClick = onOpenParen,
            hapticsEnabled = hapticsEnabled,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        )
        TactileKey(
            label = ")",
            role = KeyRole.SCIENTIFIC,
            testTag = "key_close_paren",
            onClick = onCloseParen,
            hapticsEnabled = hapticsEnabled,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        )
        TactileKey(
            label = "√",
            role = KeyRole.SCIENTIFIC,
            testTag = "key_quick_sqrt",
            onClick = onSqrt,
            hapticsEnabled = hapticsEnabled,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        )
        TactileKey(
            label = "xʸ",
            role = KeyRole.SCIENTIFIC,
            testTag = "key_quick_power",
            onClick = onPower,
            hapticsEnabled = hapticsEnabled,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        )
        TactileKey(
            label = "π",
            role = KeyRole.SCIENTIFIC,
            testTag = "key_quick_pi",
            onClick = onPi,
            hapticsEnabled = hapticsEnabled,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        )
    }
}

@Composable
fun ScientificKeypadGrid(
    isInverseMode: Boolean,
    hapticsEnabled: Boolean,
    onToggleInverse: () -> Unit,
    onFunction: (String) -> Unit,
    onConstant: (String) -> Unit,
    onSquare: () -> Unit,
    onPower: () -> Unit,
    onFactorial: () -> Unit,
    onReciprocal: () -> Unit,
    onParen: (String) -> Unit,
    modifier: Modifier = Modifier,
    rowHeight: Dp = 48.dp
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Row 1: INV, sin/sin-1, cos/cos-1, tan/tan-1, 1/x
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TactileKey(
                label = stringResource(R.string.inv_label),
                role = KeyRole.SCIENTIFIC,
                testTag = "key_inv",
                isActiveToggle = isInverseMode,
                onClick = onToggleInverse,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            val sinLabel = if (isInverseMode) "sin⁻¹" else "sin"
            val cosLabel = if (isInverseMode) "cos⁻¹" else "cos"
            val tanLabel = if (isInverseMode) "tan⁻¹" else "tan"
            TactileKey(
                label = sinLabel,
                role = KeyRole.SCIENTIFIC,
                testTag = "key_sin",
                onClick = { onFunction("$sinLabel(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = cosLabel,
                role = KeyRole.SCIENTIFIC,
                testTag = "key_cos",
                onClick = { onFunction("$cosLabel(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = tanLabel,
                role = KeyRole.SCIENTIFIC,
                testTag = "key_tan",
                onClick = { onFunction("$tanLabel(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "1/x",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_reciprocal",
                onClick = onReciprocal,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
        }

        // Row 2: ln, log, √, x², xʸ
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TactileKey(
                label = "ln",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_ln",
                onClick = { onFunction("ln(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "log",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_log",
                onClick = { onFunction("log(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "√",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_sqrt",
                onClick = { onFunction("√(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "x²",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_square",
                onClick = onSquare,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "xʸ",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_power",
                onClick = onPower,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
        }

        // Row 3: (, ), π, e, x!
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TactileKey(
                label = "(",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_sci_open_paren",
                onClick = { onParen("(") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = ")",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_sci_close_paren",
                onClick = { onParen(")") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "π",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_pi",
                onClick = { onConstant("π") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "e",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_e",
                onClick = { onConstant("e") },
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
            TactileKey(
                label = "x!",
                role = KeyRole.SCIENTIFIC,
                testTag = "key_factorial",
                onClick = onFactorial,
                hapticsEnabled = hapticsEnabled,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(rowHeight)
            )
        }
    }
}

@Composable
fun StandardKeypadGrid(
    hapticsEnabled: Boolean,
    onDigit: (String) -> Unit,
    onDecimal: () -> Unit,
    onOperator: (String) -> Unit,
    onPercent: () -> Unit,
    onToggleSign: () -> Unit,
    onBackspace: () -> Unit,
    onClearAll: () -> Unit,
    onEvaluate: () -> Unit,
    modifier: Modifier = Modifier,
    spacing: Dp = 10.dp
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(spacing)
    ) {
        // Row 1: AC, Backspace, %, ÷
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            TactileKey(
                label = "AC",
                role = KeyRole.CLEAR,
                testTag = "key_ac",
                onClick = onClearAll,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "⌫",
                icon = Icons.AutoMirrored.Rounded.Backspace,
                contentDescriptionText = stringResource(R.string.cd_backspace),
                role = KeyRole.FUNCTION,
                testTag = "key_backspace",
                onClick = onBackspace,
                onLongClick = onClearAll,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "%",
                role = KeyRole.FUNCTION,
                testTag = "key_percent",
                onClick = onPercent,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "÷",
                role = KeyRole.OPERATOR,
                testTag = "key_divide",
                onClick = { onOperator("÷") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }

        // Row 2: 7, 8, 9, ×
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("7", "8", "9").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "×",
                role = KeyRole.OPERATOR,
                testTag = "key_multiply",
                onClick = { onOperator("×") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }

        // Row 3: 4, 5, 6, −
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("4", "5", "6").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "−",
                role = KeyRole.OPERATOR,
                testTag = "key_subtract",
                onClick = { onOperator("−") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }

        // Row 4: 1, 2, 3, +
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            listOf("1", "2", "3").forEach { d ->
                TactileKey(
                    label = d,
                    role = KeyRole.DIGIT,
                    testTag = "key_$d",
                    onClick = { onDigit(d) },
                    hapticsEnabled = hapticsEnabled,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            TactileKey(
                label = "+",
                role = KeyRole.OPERATOR,
                testTag = "key_add",
                onClick = { onOperator("+") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }

        // Row 5: +/−, 0, ., =
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(spacing)
        ) {
            TactileKey(
                label = "+/−",
                role = KeyRole.DIGIT,
                testTag = "key_toggle_sign",
                onClick = onToggleSign,
                hapticsEnabled = hapticsEnabled,
                textStyle = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "0",
                role = KeyRole.DIGIT,
                testTag = "key_0",
                onClick = { onDigit("0") },
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = ".",
                role = KeyRole.DIGIT,
                testTag = "key_decimal",
                onClick = onDecimal,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
            TactileKey(
                label = "=",
                role = KeyRole.EQUALS,
                testTag = "key_equals",
                onClick = onEvaluate,
                hapticsEnabled = hapticsEnabled,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
    }
}

@Composable
fun AnimatedScientificDrawer(
    visible: Boolean,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(),
        exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()
    ) {
        content()
    }
}
