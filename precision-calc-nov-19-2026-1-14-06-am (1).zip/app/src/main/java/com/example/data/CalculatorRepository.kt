package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.AngleMode
import com.example.domain.HistoryItem
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.calculatorDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "precision_calc_prefs"
)

data class CalculatorPreferences(
    val history: List<HistoryItem> = emptyList(),
    val angleMode: AngleMode = AngleMode.DEG,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val hapticsEnabled: Boolean = true,
    val memoryValue: String = "0",
    val lastAns: String = "0"
)

class CalculatorRepository(private val context: Context) {

    private object Keys {
        val HISTORY_JSON = stringPreferencesKey("history_json")
        val ANGLE_MODE = stringPreferencesKey("angle_mode")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val MEMORY_VALUE = stringPreferencesKey("memory_value")
        val LAST_ANS = stringPreferencesKey("last_ans")
    }

    val preferencesFlow: Flow<CalculatorPreferences> = context.calculatorDataStore.data.map { prefs ->
        CalculatorPreferences(
            history = decodeHistory(prefs[Keys.HISTORY_JSON]),
            angleMode = prefs[Keys.ANGLE_MODE]?.let {
                runCatching { AngleMode.valueOf(it) }.getOrNull()
            } ?: AngleMode.DEG,
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrNull()
            } ?: ThemeMode.SYSTEM,
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            memoryValue = prefs[Keys.MEMORY_VALUE] ?: "0",
            lastAns = prefs[Keys.LAST_ANS] ?: "0"
        )
    }

    suspend fun addHistoryItem(item: HistoryItem, lastAns: String) {
        context.calculatorDataStore.edit { prefs ->
            val current = decodeHistory(prefs[Keys.HISTORY_JSON]).toMutableList()
            // Avoid duplicating identical consecutive entry
            val first = current.firstOrNull()
            if (first == null || first.expression != item.expression || first.result != item.result) {
                current.add(0, item)
            }
            val trimmed = current.take(MAX_HISTORY_ITEMS)
            prefs[Keys.HISTORY_JSON] = encodeHistory(trimmed)
            prefs[Keys.LAST_ANS] = lastAns
        }
    }

    suspend fun deleteHistoryItem(id: String) {
        context.calculatorDataStore.edit { prefs ->
            val updated = decodeHistory(prefs[Keys.HISTORY_JSON]).filterNot { it.id == id }
            prefs[Keys.HISTORY_JSON] = encodeHistory(updated)
        }
    }

    suspend fun clearHistory() {
        context.calculatorDataStore.edit { prefs ->
            prefs[Keys.HISTORY_JSON] = "[]"
        }
    }

    suspend fun setAngleMode(mode: AngleMode) {
        context.calculatorDataStore.edit { prefs ->
            prefs[Keys.ANGLE_MODE] = mode.name
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.calculatorDataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.calculatorDataStore.edit { prefs ->
            prefs[Keys.HAPTICS_ENABLED] = enabled
        }
    }

    suspend fun setMemoryValue(value: String) {
        context.calculatorDataStore.edit { prefs ->
            prefs[Keys.MEMORY_VALUE] = value
        }
    }

    private fun encodeHistory(items: List<HistoryItem>): String {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("expression", item.expression)
                    put("result", item.result)
                    put("ts", item.timestampMillis)
                }
            )
        }
        return array.toString()
    }

    private fun decodeHistory(json: String?): List<HistoryItem> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(json)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        HistoryItem(
                            id = obj.getString("id"),
                            expression = obj.getString("expression"),
                            result = obj.getString("result"),
                            timestampMillis = obj.getLong("ts")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    companion object {
        private const val MAX_HISTORY_ITEMS = 50
    }
}
