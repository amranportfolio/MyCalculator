package com.example.domain

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Recursive-descent mathematical expression parser and hybrid BigDecimal/Double evaluator.
 * Uses BigDecimal for exact base-10 arithmetic (preventing 0.1 + 0.2 floating-point drift)
 * and snapped high-precision IEEE-754 evaluation for transcendental functions.
 */
object CalculatorEngine {

    private val MC = MathContext(16, RoundingMode.HALF_UP)
    private val TRIG_MC = MathContext(12, RoundingMode.HALF_UP)
    private val HUNDRED = BigDecimal("100")
    private val MAX_SCI_THRESHOLD = BigDecimal("1E12")
    private val MIN_SCI_THRESHOLD = BigDecimal("1E-9")

    private sealed interface Token {
        data class Number(val value: BigDecimal) : Token
        data class Constant(val name: String) : Token
        data class Func(val name: String) : Token
        data class Operator(val op: Char) : Token
        data object LeftParen : Token
        data object RightParen : Token
        data object Percent : Token
        data object Factorial : Token
    }

    private sealed interface CalcNumber {
        data class Exact(val value: BigDecimal) : CalcNumber
        data class Approx(val value: Double) : CalcNumber

        fun toDouble(): Double = when (this) {
            is Exact -> value.toDouble()
            is Approx -> value
        }

        fun toBigDecimal(): BigDecimal = when (this) {
            is Exact -> value
            is Approx -> fromDoubleSnapped(value)
        }
    }

    private class EvalException(val type: CalcErrorType) : RuntimeException()

    fun evaluate(
        expression: String,
        angleMode: AngleMode = AngleMode.DEG,
        lastAns: BigDecimal = BigDecimal.ZERO
    ): EvalResult {
        val trimmed = expression.trim()
        if (trimmed.isEmpty()) {
            return EvalResult.Error(CalcErrorType.SYNTAX)
        }

        return try {
            val rawTokens = tokenize(trimmed)
            if (rawTokens.isEmpty()) {
                return EvalResult.Error(CalcErrorType.SYNTAX)
            }
            val balancedTokens = autoCloseParens(insertImplicitMultiplication(rawTokens))
            val parser = Parser(balancedTokens, angleMode, lastAns)
            val resultNum = parser.parse()
            val bd = resultNum.toBigDecimal().stripTrailingZeros()
            val normalized = if (bd.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ZERO else bd
            EvalResult.Success(
                value = normalized,
                formatted = formatResult(normalized)
            )
        } catch (e: EvalException) {
            EvalResult.Error(e.type)
        } catch (_: ArithmeticException) {
            EvalResult.Error(CalcErrorType.OVERFLOW)
        } catch (_: NumberFormatException) {
            EvalResult.Error(CalcErrorType.SYNTAX)
        }
    }

    fun formatResult(value: BigDecimal): String {
        if (value.compareTo(BigDecimal.ZERO) == 0) return "0"
        val clean = value.round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
        val absVal = clean.abs()
        return if (absVal >= MAX_SCI_THRESHOLD || (absVal > BigDecimal.ZERO && absVal < MIN_SCI_THRESHOLD)) {
            formatScientific(clean)
        } else {
            addThousandsGrouping(clean.toPlainString())
        }
    }

    fun formatRawPlain(value: BigDecimal): String {
        if (value.compareTo(BigDecimal.ZERO) == 0) return "0"
        val clean = value.round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
        return clean.toPlainString()
    }

    fun addThousandsGrouping(raw: String): String {
        if (raw.contains('E') || raw.contains('e')) return raw
        val negative = raw.startsWith("-")
        val body = if (negative) raw.substring(1) else raw
        val dotIndex = body.indexOf('.')
        val intPart = if (dotIndex >= 0) body.substring(0, dotIndex) else body
        val fracPart = if (dotIndex >= 0) body.substring(dotIndex) else ""

        if (intPart.length <= 3) return raw
        val groupedInt = buildString {
            for (i in intPart.indices) {
                if (i > 0 && (intPart.length - i) % 3 == 0) {
                    append(',')
                }
                append(intPart[i])
            }
        }
        return (if (negative) "-" else "") + groupedInt + fracPart
    }

    private fun formatScientific(value: BigDecimal): String {
        val sci = value.round(MathContext(8, RoundingMode.HALF_UP)).stripTrailingZeros().toString()
        return sci.replace("E+", "E")
    }

    private fun tokenize(input: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        val n = input.length

        while (i < n) {
            val ch = input[i]
            when {
                ch.isWhitespace() || ch == ',' -> i++
                ch.isDigit() || ch == '.' -> {
                    val start = i
                    var dotSeen = false
                    while (i < n && (input[i].isDigit() || (input[i] == '.' && !dotSeen))) {
                        if (input[i] == '.') dotSeen = true
                        i++
                    }
                    // Handle scientific notation exponent like 1.5E-4 or 2e10
                    if (i < n && (input[i] == 'E' || input[i] == 'e')) {
                        val expLookahead = i + 1
                        val hasSign = expLookahead < n && (input[expLookahead] == '+' || input[expLookahead] == '-')
                        val digitStart = if (hasSign) expLookahead + 1 else expLookahead
                        if (digitStart < n && input[digitStart].isDigit()) {
                            i = digitStart
                            while (i < n && input[i].isDigit()) i++
                        }
                    }
                    val numStr = input.substring(start, i)
                    if (numStr == ".") throw EvalException(CalcErrorType.SYNTAX)
                    tokens.add(Token.Number(BigDecimal(numStr)))
                }
                ch == 'π' -> {
                    tokens.add(Token.Constant("π"))
                    i++
                }
                ch == '√' -> {
                    tokens.add(Token.Func("sqrt"))
                    i++
                }
                ch == '(' -> {
                    tokens.add(Token.LeftParen)
                    i++
                }
                ch == ')' -> {
                    tokens.add(Token.RightParen)
                    i++
                }
                ch == '%' -> {
                    tokens.add(Token.Percent)
                    i++
                }
                ch == '!' -> {
                    tokens.add(Token.Factorial)
                    i++
                }
                ch == '+' -> {
                    tokens.add(Token.Operator('+'))
                    i++
                }
                ch == '-' || ch == '−' -> {
                    tokens.add(Token.Operator('-'))
                    i++
                }
                ch == '*' || ch == '×' -> {
                    tokens.add(Token.Operator('*'))
                    i++
                }
                ch == '/' || ch == '÷' -> {
                    tokens.add(Token.Operator('/'))
                    i++
                }
                ch == '^' -> {
                    tokens.add(Token.Operator('^'))
                    i++
                }
                ch.isLetter() -> {
                    val start = i
                    while (i < n && (input[i].isLetter() || input[i] == '⁻' || input[i] == '¹')) {
                        i++
                    }
                    val word = input.substring(start, i)
                    when (word) {
                        "e" -> tokens.add(Token.Constant("e"))
                        "Ans" -> tokens.add(Token.Constant("Ans"))
                        "sin", "cos", "tan", "asin", "acos", "atan",
                        "sin⁻¹", "cos⁻¹", "tan⁻¹", "ln", "log", "sqrt" -> {
                            val normalized = when (word) {
                                "sin⁻¹" -> "asin"
                                "cos⁻¹" -> "acos"
                                "tan⁻¹" -> "atan"
                                else -> word
                            }
                            tokens.add(Token.Func(normalized))
                        }
                        else -> throw EvalException(CalcErrorType.SYNTAX)
                    }
                }
                else -> throw EvalException(CalcErrorType.SYNTAX)
            }
        }
        return tokens
    }

    private fun insertImplicitMultiplication(tokens: List<Token>): List<Token> {
        if (tokens.size <= 1) return tokens
        val out = mutableListOf<Token>()
        for (i in tokens.indices) {
            val curr = tokens[i]
            if (i > 0) {
                val prev = tokens[i - 1]
                val prevEndsOperand = prev is Token.Number ||
                    prev is Token.Constant ||
                    prev is Token.RightParen ||
                    prev is Token.Percent ||
                    prev is Token.Factorial
                val currStartsOperand = curr is Token.Number ||
                    curr is Token.Constant ||
                    curr is Token.Func ||
                    curr is Token.LeftParen

                if (prevEndsOperand && currStartsOperand) {
                    out.add(Token.Operator('*'))
                }
            }
            out.add(curr)
        }
        return out
    }

    private fun autoCloseParens(tokens: List<Token>): List<Token> {
        var balance = 0
        for (t in tokens) {
            when (t) {
                Token.LeftParen -> balance++
                Token.RightParen -> if (balance > 0) balance-- else throw EvalException(CalcErrorType.SYNTAX)
                else -> Unit
            }
        }
        if (balance == 0) return tokens
        return tokens + List(balance) { Token.RightParen }
    }

    private class Parser(
        private val tokens: List<Token>,
        private val angleMode: AngleMode,
        private val lastAns: BigDecimal
    ) {
        private var pos = 0

        fun parse(): CalcNumber {
            val result = parseAddSub()
            if (pos < tokens.size) {
                throw EvalException(CalcErrorType.SYNTAX)
            }
            return result
        }

        private fun peek(): Token? = tokens.getOrNull(pos)

        private fun consume(): Token = tokens[pos++]

        private fun parseAddSub(): CalcNumber {
            var left = parseMulDiv()
            while (true) {
                val op = (peek() as? Token.Operator)?.op ?: break
                if (op != '+' && op != '-') break
                consume()
                val right = parseMulDiv()
                left = if (op == '+') add(left, right) else subtract(left, right)
            }
            return left
        }

        private fun parseMulDiv(): CalcNumber {
            var left = parseUnary()
            while (true) {
                val op = (peek() as? Token.Operator)?.op ?: break
                if (op != '*' && op != '/') break
                consume()
                val right = parseUnary()
                left = if (op == '*') multiply(left, right) else divide(left, right)
            }
            return left
        }

        private fun parseUnary(): CalcNumber {
            val token = peek()
            if (token is Token.Operator && (token.op == '+' || token.op == '-')) {
                consume()
                val operand = parseUnary()
                return if (token.op == '-') negate(operand) else operand
            }
            return parsePower()
        }

        private fun parsePower(): CalcNumber {
            val base = parsePostfix()
            val token = peek()
            if (token is Token.Operator && token.op == '^') {
                consume()
                // Right-associative power with unary support (e.g. 2^-3)
                val exponent = parseUnary()
                return power(base, exponent)
            }
            return base
        }

        private fun parsePostfix(): CalcNumber {
            var value = parsePrimary()
            while (true) {
                when (peek()) {
                    Token.Percent -> {
                        consume()
                        value = when (value) {
                            is CalcNumber.Exact -> CalcNumber.Exact(value.value.divide(HUNDRED, MC))
                            is CalcNumber.Approx -> CalcNumber.Approx(value.value / 100.0)
                        }
                    }
                    Token.Factorial -> {
                        consume()
                        value = factorial(value)
                    }
                    else -> break
                }
            }
            return value
        }

        private fun parsePrimary(): CalcNumber {
            return when (val token = peek() ?: throw EvalException(CalcErrorType.SYNTAX)) {
                is Token.Number -> {
                    consume()
                    CalcNumber.Exact(token.value)
                }
                is Token.Constant -> {
                    consume()
                    when (token.name) {
                        "π" -> CalcNumber.Approx(PI)
                        "e" -> CalcNumber.Approx(kotlin.math.E)
                        "Ans" -> CalcNumber.Exact(lastAns)
                        else -> throw EvalException(CalcErrorType.SYNTAX)
                    }
                }
                is Token.Func -> {
                    consume()
                    val arg = if (peek() == Token.LeftParen) {
                        consume()
                        val inner = parseAddSub()
                        if (peek() != Token.RightParen) throw EvalException(CalcErrorType.SYNTAX)
                        consume()
                        inner
                    } else {
                        parseUnary()
                    }
                    applyFunction(token.name, arg)
                }
                Token.LeftParen -> {
                    consume()
                    val inner = parseAddSub()
                    if (peek() != Token.RightParen) throw EvalException(CalcErrorType.SYNTAX)
                    consume()
                    inner
                }
                else -> throw EvalException(CalcErrorType.SYNTAX)
            }
        }

        private fun add(a: CalcNumber, b: CalcNumber): CalcNumber {
            return if (a is CalcNumber.Exact && b is CalcNumber.Exact) {
                CalcNumber.Exact(a.value.add(b.value, MC))
            } else {
                val res = a.toDouble() + b.toDouble()
                checkFinite(res)
                CalcNumber.Approx(res)
            }
        }

        private fun subtract(a: CalcNumber, b: CalcNumber): CalcNumber {
            return if (a is CalcNumber.Exact && b is CalcNumber.Exact) {
                CalcNumber.Exact(a.value.subtract(b.value, MC))
            } else {
                val res = a.toDouble() - b.toDouble()
                checkFinite(res)
                CalcNumber.Approx(res)
            }
        }

        private fun multiply(a: CalcNumber, b: CalcNumber): CalcNumber {
            return if (a is CalcNumber.Exact && b is CalcNumber.Exact) {
                CalcNumber.Exact(a.value.multiply(b.value, MC))
            } else {
                val res = a.toDouble() * b.toDouble()
                checkFinite(res)
                CalcNumber.Approx(res)
            }
        }

        private fun divide(a: CalcNumber, b: CalcNumber): CalcNumber {
            if (b is CalcNumber.Exact && b.value.compareTo(BigDecimal.ZERO) == 0) {
                throw EvalException(CalcErrorType.DIVIDE_BY_ZERO)
            }
            val bDouble = b.toDouble()
            if (bDouble == 0.0) throw EvalException(CalcErrorType.DIVIDE_BY_ZERO)

            return if (a is CalcNumber.Exact && b is CalcNumber.Exact) {
                CalcNumber.Exact(a.value.divide(b.value, MC))
            } else {
                val res = a.toDouble() / bDouble
                checkFinite(res)
                CalcNumber.Approx(res)
            }
        }

        private fun negate(a: CalcNumber): CalcNumber = when (a) {
            is CalcNumber.Exact -> CalcNumber.Exact(a.value.negate())
            is CalcNumber.Approx -> CalcNumber.Approx(-a.value)
        }

        private fun power(base: CalcNumber, expVal: CalcNumber): CalcNumber {
            if (base is CalcNumber.Exact && expVal is CalcNumber.Exact) {
                val e = expVal.value.stripTrailingZeros()
                if (e.scale() <= 0 && e.abs() <= BigDecimal(999)) {
                    val intExp = e.toInt()
                    if (intExp >= 0) {
                        return CalcNumber.Exact(base.value.pow(intExp, MC))
                    } else {
                        if (base.value.compareTo(BigDecimal.ZERO) == 0) {
                            throw EvalException(CalcErrorType.DIVIDE_BY_ZERO)
                        }
                        val posPow = base.value.pow(-intExp, MC)
                        return CalcNumber.Exact(BigDecimal.ONE.divide(posPow, MC))
                    }
                }
            }
            val b = base.toDouble()
            val p = expVal.toDouble()
            if (b == 0.0 && p < 0.0) throw EvalException(CalcErrorType.DIVIDE_BY_ZERO)
            val res = b.pow(p)
            if (res.isNaN()) throw EvalException(CalcErrorType.DOMAIN)
            checkFinite(res)
            return CalcNumber.Approx(res)
        }

        private fun factorial(n: CalcNumber): CalcNumber {
            val d = n.toDouble()
            if (d < 0 || d.isNaN() || d.isInfinite() || abs(d - kotlin.math.round(d)) > 1e-10) {
                throw EvalException(CalcErrorType.DOMAIN)
            }
            val intN = kotlin.math.round(d).toInt()
            if (intN > 170) throw EvalException(CalcErrorType.OVERFLOW)
            if (intN <= 20) {
                var acc = BigDecimal.ONE
                for (k in 2..intN) {
                    acc = acc.multiply(BigDecimal(k))
                }
                return CalcNumber.Exact(acc)
            }
            var acc = 1.0
            for (k in 2..intN) {
                acc *= k
            }
            checkFinite(acc)
            return CalcNumber.Approx(acc)
        }

        private fun applyFunction(name: String, arg: CalcNumber): CalcNumber {
            val x = arg.toDouble()
            val res = when (name) {
                "sqrt" -> {
                    if (x < 0.0) throw EvalException(CalcErrorType.DOMAIN)
                    sqrt(x)
                }
                "ln" -> {
                    if (x <= 0.0) throw EvalException(CalcErrorType.DOMAIN)
                    ln(x)
                }
                "log" -> {
                    if (x <= 0.0) throw EvalException(CalcErrorType.DOMAIN)
                    log10(x)
                }
                "sin" -> {
                    val rad = toRadians(x)
                    snapZero(sin(rad))
                }
                "cos" -> {
                    val rad = toRadians(x)
                    snapZero(cos(rad))
                }
                "tan" -> {
                    val rad = toRadians(x)
                    val c = cos(rad)
                    if (abs(c) < 1e-12) throw EvalException(CalcErrorType.DOMAIN)
                    snapZero(tan(rad))
                }
                "asin" -> {
                    if (x < -1.0 || x > 1.0) throw EvalException(CalcErrorType.DOMAIN)
                    fromRadians(asin(x))
                }
                "acos" -> {
                    if (x < -1.0 || x > 1.0) throw EvalException(CalcErrorType.DOMAIN)
                    fromRadians(acos(x))
                }
                "atan" -> {
                    fromRadians(atan(x))
                }
                "exp" -> exp(x)
                else -> throw EvalException(CalcErrorType.SYNTAX)
            }
            if (res.isNaN()) throw EvalException(CalcErrorType.DOMAIN)
            checkFinite(res)
            return CalcNumber.Approx(snapZero(res))
        }

        private fun toRadians(value: Double): Double =
            if (angleMode == AngleMode.DEG) value * (PI / 180.0) else value

        private fun fromRadians(rad: Double): Double =
            if (angleMode == AngleMode.DEG) rad * (180.0 / PI) else rad

        private fun snapZero(v: Double): Double = if (abs(v) < 1e-12) 0.0 else v

        private fun checkFinite(v: Double) {
            if (v.isInfinite()) throw EvalException(CalcErrorType.OVERFLOW)
            if (v.isNaN()) throw EvalException(CalcErrorType.DOMAIN)
        }
    }

    private fun fromDoubleSnapped(d: Double): BigDecimal {
        if (d.isInfinite()) throw EvalException(CalcErrorType.OVERFLOW)
        if (d.isNaN()) throw EvalException(CalcErrorType.DOMAIN)
        if (abs(d) < 1e-12) return BigDecimal.ZERO
        return BigDecimal.valueOf(d).round(TRIG_MC).stripTrailingZeros()
    }
}
