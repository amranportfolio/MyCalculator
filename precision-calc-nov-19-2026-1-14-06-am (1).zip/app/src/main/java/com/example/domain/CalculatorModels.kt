package com.example.domain

import java.math.BigDecimal

enum class AngleMode {
    DEG, RAD
}

enum class CalcErrorType {
    DIVIDE_BY_ZERO,
    DOMAIN,
    SYNTAX,
    OVERFLOW
}

sealed interface EvalResult {
    data class Success(
        val value: BigDecimal,
        val formatted: String
    ) : EvalResult

    data class Error(val type: CalcErrorType) : EvalResult
}

data class HistoryItem(
    val id: String,
    val expression: String,
    val result: String,
    val timestampMillis: Long
)
