package com.example.domain

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

enum class UnitCategory(val displayName: String) {
    LENGTH("Length"),
    MASS("Mass"),
    TEMPERATURE("Temperature"),
    AREA("Area"),
    VOLUME("Volume"),
    DATA("Data")
}

data class MeasureUnit(
    val id: String,
    val name: String,
    val symbol: String,
    val factorToBase: Double = 1.0
)

object UnitConverter {

    private val MC = MathContext(10, RoundingMode.HALF_UP)

    val unitsByCategory: Map<UnitCategory, List<MeasureUnit>> = mapOf(
        UnitCategory.LENGTH to listOf(
            MeasureUnit("m", "Meter", "m", 1.0),
            MeasureUnit("km", "Kilometer", "km", 1000.0),
            MeasureUnit("cm", "Centimeter", "cm", 0.01),
            MeasureUnit("mm", "Millimeter", "mm", 0.001),
            MeasureUnit("mi", "Mile", "mi", 1609.344),
            MeasureUnit("yd", "Yard", "yd", 0.9144),
            MeasureUnit("ft", "Foot", "ft", 0.3048),
            MeasureUnit("in", "Inch", "in", 0.0254)
        ),
        UnitCategory.MASS to listOf(
            MeasureUnit("kg", "Kilogram", "kg", 1.0),
            MeasureUnit("g", "Gram", "g", 0.001),
            MeasureUnit("mg", "Milligram", "mg", 1e-6),
            MeasureUnit("lb", "Pound", "lb", 0.45359237),
            MeasureUnit("oz", "Ounce", "oz", 0.028349523125),
            MeasureUnit("t", "Metric Ton", "t", 1000.0)
        ),
        UnitCategory.TEMPERATURE to listOf(
            MeasureUnit("c", "Celsius", "°C"),
            MeasureUnit("f", "Fahrenheit", "°F"),
            MeasureUnit("k", "Kelvin", "K")
        ),
        UnitCategory.AREA to listOf(
            MeasureUnit("sqm", "Square Meter", "m²", 1.0),
            MeasureUnit("sqkm", "Square Kilometer", "km²", 1_000_000.0),
            MeasureUnit("ha", "Hectare", "ha", 10_000.0),
            MeasureUnit("acre", "Acre", "ac", 4046.8564224),
            MeasureUnit("sqft", "Square Foot", "ft²", 0.09290304),
            MeasureUnit("sqin", "Square Inch", "in²", 0.00064516)
        ),
        UnitCategory.VOLUME to listOf(
            MeasureUnit("l", "Liter", "L", 1.0),
            MeasureUnit("ml", "Milliliter", "mL", 0.001),
            MeasureUnit("m3", "Cubic Meter", "m³", 1000.0),
            MeasureUnit("gal", "US Gallon", "gal", 3.785411784),
            MeasureUnit("qt", "US Quart", "qt", 0.946352946),
            MeasureUnit("cup", "US Cup", "cup", 0.2365882365)
        ),
        UnitCategory.DATA to listOf(
            MeasureUnit("b", "Byte", "B", 1.0),
            MeasureUnit("kb", "Kilobyte", "KB", 1000.0),
            MeasureUnit("mb", "Megabyte", "MB", 1_000_000.0),
            MeasureUnit("gb", "Gigabyte", "GB", 1_000_000_000.0),
            MeasureUnit("tb", "Terabyte", "TB", 1_000_000_000_000.0),
            MeasureUnit("kib", "Kibibyte", "KiB", 1024.0),
            MeasureUnit("mib", "Mebibyte", "MiB", 1_048_576.0),
            MeasureUnit("gib", "Gibibyte", "GiB", 1_073_741_824.0)
        )
    )

    fun convert(
        value: Double,
        category: UnitCategory,
        from: MeasureUnit,
        to: MeasureUnit
    ): Double {
        if (from.id == to.id) return value
        return if (category == UnitCategory.TEMPERATURE) {
            val celsius = when (from.id) {
                "c" -> value
                "f" -> (value - 32.0) * 5.0 / 9.0
                "k" -> value - 273.15
                else -> value
            }
            when (to.id) {
                "c" -> celsius
                "f" -> celsius * 9.0 / 5.0 + 32.0
                "k" -> celsius + 273.15
                else -> celsius
            }
        } else {
            val baseValue = value * from.factorToBase
            baseValue / to.factorToBase
        }
    }

    fun formatConverted(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "Error"
        if (value == 0.0) return "0"
        val bd = BigDecimal.valueOf(value).round(MC).stripTrailingZeros()
        val normalized = if (bd.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ZERO else bd
        return CalculatorEngine.formatResult(normalized)
    }
}
